const express = require('express');
const router = express.Router();
const Post = require('../models/Post');
const Alumni = require('../models/Alumni');
const auth = require('../middleware/auth');
const multer = require('multer');
const cloudinary = require('../config/cloudinary');

// Multer setup for file upload
const storage = multer.memoryStorage();
const upload = multer({ storage });

// Create a post (alumni only)
router.post('/', auth, upload.single('image'), async (req, res) => {
  try {
    // Only alumni can post
    const user = req.user;
    const alumni = await Alumni.findById(user.id);
    if (!alumni) return res.status(403).json({ error: 'Only alumni can post' });

    let imageUrl = '';
    if (req.file) {
      // Upload image to Cloudinary
      const result = await cloudinary.uploader.upload_stream(
        { folder: 'alumni_posts' },
        (error, result) => {
          if (error) throw error;
          imageUrl = result.secure_url;
        }
      );
      // Use a promise to wait for upload_stream
      await new Promise((resolve, reject) => {
        const stream = cloudinary.uploader.upload_stream(
          { folder: 'alumni_posts' },
          (error, result) => {
            if (error) reject(error);
            imageUrl = result.secure_url;
            resolve();
          }
        );
        stream.end(req.file.buffer);
      });
    }

    const post = new Post({
      author: alumni._id,
      content: req.body.content,
      image: imageUrl
    });
    await post.save();
    res.status(201).json(post);
  } catch (err) {
    res.status(500).json({ error: 'Failed to create post', details: err.message });
  }
});

// Get all posts (for dashboard feed)
router.get('/', auth, async (req, res) => {
  try {
    const posts = await Post.find().populate('author', 'name img').sort({ createdAt: -1 });
    res.json(posts);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch posts' });
  }
});

module.exports = router;
